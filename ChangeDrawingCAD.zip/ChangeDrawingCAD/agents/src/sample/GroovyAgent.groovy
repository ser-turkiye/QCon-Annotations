package sample

import com.google.gson.GsonBuilder
import de.ser.doxis4.agentserver.UnifiedAgent

// To test this agent class: gradle run --args "sample.GroovyAgent"

// Uncomment this line when copying the source code into the SOAP Admin Client
//new GroovyAgent().execute(binding.variables)

@groovy.transform.CompileStatic
class GroovyAgent extends UnifiedAgent {

    @Override
    protected Object execute() {
        // This is how logging should be done UnifiedAgent in CSB 4.2+
        JCLLog.info("Hello a Groovy UnifedAgent via apache.commons.logging")
        // The old log4j1 Logger is deprecated but still works
        log.info("Hello via log4j1")
        def gson = new GsonBuilder().setPrettyPrinting().create();
        def car = new Car()
        car.csbVersion = getServerVersion();
        resultSuccess(gson.toJson(car))
    }

    String getServerVersion() {
        return srv.serverInfo.serverVersion
    }

    private class Car {
        public String manufacturer = "Honda"
        public String brand = "Civic"
        public String csbVersion = null
    }

}
