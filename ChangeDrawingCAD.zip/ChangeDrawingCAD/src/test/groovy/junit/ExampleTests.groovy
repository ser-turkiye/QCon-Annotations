package junit

import de.ser.doxis4.agentserver.AgentExecutionResult
import de.ser.hh.groovy.tester.AgentTester
import me.presales.cad.CreateNewVersionForSource
import me.presales.cad.OnInitiateChangeDrawing
import org.junit.*


class ExampleTests {

    Binding binding

    @BeforeClass
    static void initSessionPool() {
        AgentTester.initSessionPool()
    }

    @Before
    void retrieveBinding() {
        binding = AgentTester.retrieveBinding()
    }

    @Test
    void testForAgentResult() {
        def agent = new CreateNewVersionForSource()
        binding["AGENT_EVENT_OBJECT_CLIENT_ID"] =
            "SD07PRJ_DOC24cfe474c7-72c3-43a1-be63-6eafc39872d6182023-07-20T11:41:38.283Z012"
        def result = (AgentExecutionResult)agent.execute(binding.variables)
//        assert result.resultCode == 0
//        assert result.executionMessage.contains("Linux")
//        assert agent.eventInfObj instanceof IDocument
    }

    @Test
    void testForGroovyAgentMethod() {
//        def agent = new GroovyAgent()
//        agent.initializeGroovyBlueline(binding.variables)
//        assert agent.getServerVersion().contains("Linux")
    }

    @Test
    void testForJavaAgentMethod() {
//        def agent = new JavaAgent()
//        agent.initializeGroovyBlueline(binding.variables)
//        assert agent.getServerVersion().contains("Linux")
    }

    @After
    void releaseBinding() {
        AgentTester.releaseBinding(binding)
    }

    @AfterClass
    static void closeSessionPool() {
        AgentTester.closeSessionPool()
    }
}
