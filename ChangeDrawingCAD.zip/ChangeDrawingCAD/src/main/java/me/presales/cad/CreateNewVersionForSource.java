package me.presales.cad;

import com.ser.blueline.*;
import com.ser.blueline.bpm.IProcessInstance;
import com.ser.blueline.bpm.ITask;
import de.ser.doxis4.agentserver.UnifiedAgent;
import me.presales.cad.utils.Constants;
import me.presales.cad.utils.ProcessHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class CreateNewVersionForSource extends UnifiedAgent {
    private IDocument mainDocument;
    private IDocument taskChildDocument;
    private boolean allSubTasksCompleted;
    private ProcessHelper processHelper;
    private Logger log = LogManager.getLogger();


    @Override
    protected Object execute() {
        //When CAD creates a new version it will be without our descriptors, it overwrites all of our descriptors
        //(1) Check if we have a new version of the document
        //(2) Once we have a new version we can get the main document from the ID we have and update it
        //(3) Then we can update all the child tasks that there is a new version available out there
        if(getEventTask() == null) return resultError("OBJECT CLIENT ID is NULL or not of type ITask");
        try{
            processHelper = new ProcessHelper(getSes());
            this.getMainAndChildDocuments();
            childIssueCompletedUpdate();
            updateAllChildTasks();
            if(checkIfNewVersionExisits())updateMainDocumentWithChildDocument();
            if(allSubTasksCompleted) {
                clearDrawingTaskInformationFromMainDocument();
                deleteAllChildDrawings();
            }

        }catch (Exception e){
            log.error("Exception Caught");
            log.error(e.getMessage());
            return resultError(e.getMessage());
        }

        return resultSuccess("Agent Finished");
    }

    //Updates the child tasks so the user knows that there is a new version of the drawing
    private void updateAllChildTasks(){
        log.info("Updating All Child Task's Latest Drawing to False");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("TYPE = '").append(Constants.ClassIDs.ChangeDrawing_WF).append("'");
        stringBuilder.append(" AND TASKISSUESID  = '").append(getEventTask().getDescriptorValue(Constants.Descriptors.MainTaskID)).append("'");
        stringBuilder.append(" AND WFL_TASK_STATUS IN (2, 4)");
        String dbName = "BPM";
        IInformationObject[] childTasks = processHelper.createQuery(new String[]{dbName}, stringBuilder.toString() , 20);
        log.info("Found " + childTasks.length + " child tasks");
        //Just make sure we skip the one we are in now
        for(IInformationObject childTask : childTasks){
            try {
                childTask.setDescriptorValue(Constants.Descriptors.LatestDrawingVersion , "false");
                if(((ITask)childTask).getProcessInstance().findLockInfo().getOwner() == null){
                    log.info("Comitting change for child task");
                    childTask.commit();
                }else{
                    log.info("[CHILD TASK] Child Task is Locked Update skipped");
                }
            } catch (Exception e) {
                log.error("Exception caught");
                log.error(e.getMessage());
            }
        }
    }
    private void deleteAllChildDrawings(){
        log.info("Deleting All Child Drawings");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("TYPE = '").append(Constants.ClassIDs.ChangeDrawing_WF).append("'");
        stringBuilder.append(" AND TASKISSUESID  = '").append(getEventTask().getDescriptorValue(Constants.Descriptors.MainTaskID)).append("'");
        String dbName = "BPM";
        IInformationObject[] childTasks = processHelper.createQuery(new String[]{dbName}, stringBuilder.toString() , 100);

        //Just make sure we skip the one we are in now
        List<String> deletedProcessInstancs = new ArrayList<>();
        for(IInformationObject childTask : childTasks){
            try {
                IProcessInstance pi = ((ITask)childTask).getProcessInstance();
                if(deletedProcessInstancs.contains(pi.getID())) continue;
                deletedProcessInstancs.add(pi.getID());
                IInformationObject doc = pi.getMainInformationObject();
                if(doc != null && doc instanceof IDocument){
                    IDocumentHitList hitList = getDocumentServer().searchAllVersions((IDocument) doc , getSes());
                    getDocumentServer().deleteInformationObjects(getSes() , hitList.getInformationObjects());
                }
            } catch (Exception e) {
                log.error("Exception caught");
                log.error(e.getMessage());
            }
        }
    }
    //Once all sub-tasks finish we clear the information for the main drawing document so that we dont confuse the users
    private void clearDrawingTaskInformationFromMainDocument(){
        mainDocument.setDescriptorValue(Constants.Descriptors.LatestDrawingVersion , "");
        mainDocument.setDescriptorValue(Constants.Descriptors.MainTaskID , "");
        mainDocument.setDescriptorValue(Constants.Descriptors.MainDrawingID , "");
        mainDocument.setDescriptorValue(Constants.Descriptors.NumberOfIssues , "");
        mainDocument.setDescriptorValue(Constants.Descriptors.PendingIssues , "");
        mainDocument.commit();
    }
    //Once version updates we update the descripotrs of the main document to keep track of how many child tasks finished
    private void childIssueCompletedUpdate(){
        String pendingIssues = mainDocument.getDescriptorValue(Constants.Descriptors.PendingIssues);
        int pendingIssuesNumber = Integer.parseInt(pendingIssues);
        pendingIssuesNumber--;
        mainDocument.setDescriptorValue(Constants.Descriptors.PendingIssues , ""+pendingIssuesNumber);
        allSubTasksCompleted = pendingIssuesNumber ==0;
    }
    private void updateMainDocumentWithChildDocument(){
        IDocument newMainDocument = this.processHelper.createNewVersionCopy(mainDocument , taskChildDocument);
    }
    private boolean checkIfNewVersionExisits(){
        ///@Leonard please fill this so we know if the document has any changes on it
        return true;
    }
    private void getMainAndChildDocuments() throws Exception{
        IInformationObject mainObj = getEventTask().getProcessInstance().getMainInformationObject();
        if (mainObj == null) throw new Exception("Main Object Not found in task");
        if (!(mainObj instanceof IDocument)) throw new Exception("Main Object is not of Type IDocument");
        if(!(mainObj.getClassID().equals(Constants.ClassIDs.CADDrawing_Doc))) throw new Exception("Main Object is not a CAD document class");
        IDocument taskChildDocumentOldVersion = ((IDocument) mainObj);
        this.taskChildDocument = getDocumentServer().searchDocumentVersion(getSes() , taskChildDocumentOldVersion , VersionIdentifier.NEWEST_VERSION);
        IDocument mainDocoldVersion = getDocumentServer().getDocument4ID(getEventTask().getDescriptorValue(Constants.Descriptors.MainDrawingID) , getSes());
        if(mainDocoldVersion == null) throw new Exception("Main Document wasn't found");
        this.mainDocument = getDocumentServer().searchDocumentVersion(getSes() , mainDocoldVersion , VersionIdentifier.NEWEST_VERSION);
    }
}
