package me.presales.cad.utils;

public class Constants {
    public static class ClassIDs {
        public static final String CADDrawing_Doc = "e50141f6-90c9-4c07-a10b-8b37be26adb8";
        public static final String DrawingIssues_Doc = "cc325747-4167-48f7-bd1d-74cbcc91d9fe";

        public static final String ChangeDrawing_WF = "f4a4f055-55fe-4a63-ad86-6329ef4d0919";
        public static final String InitiaiteChangeDrawing_WF = "b3710bc5-fb9b-4c18-92c5-c707df436449";

    }
    public static class Descriptors{
        public static final String ProjectLead = "ProjectLead";
        public static final String ProjectLeadID = "ProjectLeadID";
        public static final String ProjectLeadWBID = "ProjectLeadWBID";
        public static final String InitaitorID="ProcessInitiatorID";
        public static final String InitiatorWBID ="ProcessInitiatorWBID";
        public static final String MainTaskID="TaskIssuesID";
        public static final String MainDrawingID = "MainDrawingID";
        public static final String NumberOfIssues = "NumberOfIssues";
        public static final String PendingIssues = "PendingChildTasks";
        public static final String IssueDescription = "IssueDescription";
        public static final String LatestDrawingVersion = "LatestDrawingVersion";
    }
}
