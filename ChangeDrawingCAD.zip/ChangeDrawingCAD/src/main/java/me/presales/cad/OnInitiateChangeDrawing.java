package me.presales.cad;

import com.ser.blueline.*;
import com.ser.blueline.bpm.IProcessInstance;
import com.ser.blueline.bpm.IWorkbasket;
import de.ser.doxis4.agentserver.UnifiedAgent;
import me.presales.cad.utils.Constants;
import me.presales.cad.utils.ProcessHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class OnInitiateChangeDrawing extends UnifiedAgent {
    private Logger log = LogManager.getLogger();
    private IDocument mainDocument;
    private ProcessHelper processHelper;
    @Override
    protected Object execute() {
        //Make sure we have a main document should be of Class (CAD)
        //Make sure we have issues which should be of Class (DrawingIssues)
        //Create a Copy of the Main Document for as many issues we have and trigger the workflow
        //Maintain all needed descriptors for parent -> child , child -> sibling communication
        if(getEventTask() == null) return resultError("OBJECT CLIENT ID is NULL or not of type ITask");
        try{
            this.processHelper = new ProcessHelper(getSes());
            //Getting the Main CAD drawing
            this.mainDocument = getMainDocument();
            //Getting the Issues of type DrawingIssues
            List<IDocument> issues = getIssues();
            //Populating neccesarry information for the task recievers and owners
            this.populateInitiatorProjectLeadInformation();
            //We make sure to flag that currently this is the latest version of the document
            getEventTask().setDescriptorValue(Constants.Descriptors.LatestDrawingVersion , "true");
            //Populating the TaskID and DocumentID that will be used for queiries
            this.populateDocumentandTaskID();
            //Populate the issue information Number of issues and pending issues
            this.populateIssuesInformation(issues.size());
            //Pass all populated values to the main document
            this.mainDocumentToTakeInformationFromMainTask();

            for(IDocument issue : issues){
                log.info("Starting a new task for issue: " + issue.getDisplayName());
                this.startNewChangeDrawingProcessForIssue(issue);
            }

        }catch (Exception e){
            log.error("Exception Caught");
            log.error(e.getMessage());
            return resultError(e.getMessage());
        }
        return resultSuccess("Agent Finished Sucessfully");
    }

    //Start a workflow for each issue
    private void startNewChangeDrawingProcessForIssue(IDocument issue) throws Exception{
        //(1) The sub task will take the issue description from the document
        //(2) Inherenit everything needed from the main task
        String issueDescription = issue.getDescriptorValue(Constants.Descriptors.IssueDescription);
        issueDescription = issueDescription == null ? "<Issue>" : issueDescription;

        IProcessInstance newProcessInstance = this.processHelper.buildNewProcessInstanceForID(Constants.ClassIDs.ChangeDrawing_WF);
        if(newProcessInstance == null) throw new Exception("Unable to build new process instance for ID:" + Constants.ClassIDs.ChangeDrawing_WF);
        newProcessInstance.setDescriptorValue(Constants.Descriptors.IssueDescription , issueDescription);
        this.processHelper.mapDescriptorsFromObjectToObject(getEventTask() , newProcessInstance , false);
        IDocument newDocumentCopy = this.processHelper.createDocumentCopy(mainDocument);

        newProcessInstance.setMainInformationObjectID(newDocumentCopy.getID());
        newProcessInstance.getLoadedInformationObjectLinks().addInformationObject(issue.getID());

        newProcessInstance.commit();

    }

    //Pass all information to the main document
    private void mainDocumentToTakeInformationFromMainTask(){
        log.info("Mapping Descriptors from Main Task to Main Document");
        this.processHelper.mapDescriptorsFromObjectToObject(getEventTask() , mainDocument , false);
        log.info("Saving Changes");
        mainDocument.commit();
    }
    //Populate the Nummber of issues and set it as a the pending issues
    private void populateIssuesInformation(int numberOfIssues){
        log.info("Populating Number of Issues");
        String numberOfIssuesStr = String.valueOf(numberOfIssues);
        log.info("Total Issues: " + numberOfIssuesStr);
        getEventTask().setDescriptorValue(Constants.Descriptors.NumberOfIssues , numberOfIssuesStr);
        getEventTask().setDescriptorValue(Constants.Descriptors.PendingIssues , numberOfIssuesStr);
        log.info("Saving Changes");
        getEventTask().commit();
    }

    //Obtains an ID for the MainTask to be passed to all child classes
    private void populateDocumentandTaskID(){
        //(1) Generate a unique number for the main task based on an id
        //(2) Put on the main task so they could all get it
        //(3) put the main document id on the main task as well
        log.info("Generating Next ID for main task");
        long nextCounterValue = getSes().getNextCounterValue((long)100023, "DRAWINGISSUE_TASK", (long)10000, 1L);
        String mainTaskID = "MainTask_" + nextCounterValue;
        log.info("ID: " + mainTaskID);
        getEventTask().setDescriptorValue(Constants.Descriptors.MainTaskID , mainTaskID);
        log.info("Setting Main Drawing ID from Main Document");
        getEventTask().setDescriptorValue(Constants.Descriptors.MainDrawingID , mainDocument.getID());
        log.info("Saving Changes");
        getEventTask().commit();

    }
    //Obtains the ProjectLeadID from the main document and ownerID to populate info
    private void populateInitiatorProjectLeadInformation() throws Exception{
        log.info("Populating Initiator and Project Lead Information");
        String projectLeadID = mainDocument.getDescriptorValue(Constants.Descriptors.ProjectLead);
        if(projectLeadID == null) throw new Exception("Project Lead ID descriptor on main document is empty");
        log.info("Extracted Project Lead ID: " + projectLeadID);
        String ownerID = getEventTask().getProcessInstance().getOwnerID();
        IUser projectLeadUser = getDocumentServer().getUser(getSes() , projectLeadID);
        if(projectLeadUser == null) throw new Exception("Project Lead User with ID: " + projectLeadID + " not found");
        IUser ownerUser = getDocumentServer().getUser(getSes() , ownerID);
        if(ownerUser == null) throw new Exception("Owner  User with ID: " + ownerID + " not found");
        log.info("Owner User: " + ownerUser.getFullName());
        log.info("Getting Workbasket Information for ProjectLead and Owner");
        IWorkbasket projectLeadWB = getBpm().getWorkbasketByAssociatedOrgaElement(projectLeadUser);
        if(projectLeadWB == null) throw new Exception("Project Lead doesn't have a workbaskset");
        IWorkbasket ownerWB = getBpm().getWorkbasketByAssociatedOrgaElement(ownerUser);
        if(ownerWB == null) throw new Exception("Owner User doesnt have a workbasket");
        log.info("Saving new information to task");
        getEventTask().setDescriptorValue(Constants.Descriptors.ProjectLeadID , projectLeadID);
        getEventTask().setDescriptorValue(Constants.Descriptors.ProjectLeadWBID , projectLeadWB.getID());
        getEventTask().setDescriptorValue(Constants.Descriptors.InitaitorID , ownerID);
        getEventTask().setDescriptorValue(Constants.Descriptors.InitiatorWBID , ownerWB.getID());
        log.info("Commiting new information to task");
        getEventTask().commit();
    }
    private IDocument getMainDocument() throws Exception {
        log.info("Getting Main Document from task");
        IInformationObject mainObj = getEventTask().getProcessInstance().getMainInformationObject();
        if (mainObj == null) throw new Exception("Main Object Not found in task");
        if (!(mainObj instanceof IDocument)) throw new Exception("Main Object is not of Type IDocument");
        if(!(mainObj.getClassID().equals(Constants.ClassIDs.CADDrawing_Doc))) throw new Exception("Main Object is not a CAD document class");
        return (IDocument) mainObj;
    }

    private List<IDocument> getIssues() throws Exception{
        log.info("Getting Drawing Issues from task");
        IProcessInstance processInstance = getEventTask().getProcessInstance();
        String mainInfoObjID = processInstance.getMainInformationObjectID();
        List<ILink> links = processInstance.getLoadedInformationObjectLinks().getLinks();
        if(links.size() < 2) throw new Exception("No Drawing Issues Found in Task");
        log.info("Extracting Issues from linked documents");
        ArrayList<IDocument> issues = new ArrayList<>();
        for(int i=0 ; i< links.size() ; i++){
            IInformationObject infoObject = links.get(i).getTargetInformationObject();
            if(infoObject.equals(mainInfoObjID)) continue;
            if(!(infoObject instanceof IDocument)) continue;
            if(!(infoObject.getClassID().equals(Constants.ClassIDs.DrawingIssues_Doc))) continue;
            issues.add((IDocument) infoObject);
        }
        if(issues.size() < 1) throw new Exception("Out of " + links.size() + " no drawingissues were found");
        return issues;
    }
}
